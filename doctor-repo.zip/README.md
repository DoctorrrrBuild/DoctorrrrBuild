# Doctor

A single-file documentation language that compiles to clean HTML. No terminal, no build tools, no dependencies.

## How It Works

1. **Fork this repository**
2. **Edit `.doctor` files** in the `docs/` folder (directly on GitHub)
3. **Push your changes** — GitHub Actions auto-compiles and deploys to Pages
4. **Your docs are live**

## The Language

Every component is `name#content`:

```
title# Page Title
nav# Label | #href
sidebar# Label | #href

hero# Big Title
desc# Subtitle text

h1# Heading
h2# Subheading
h3# Sub-subheading

p# Text with **bold** and *italic* and `code`
p# [Links](https://example.com) work too

code#python
def hello():
    return "Hello"
end#

table# Col1 | Col2 | Col3
Row 1 | Data | More
Row 2 | Data | More
end#

list#
- First item
- Second item
end#

alert#info
 p# This is an info callout

alert#warning
 p# This is a warning

card# Card Title
desc# Card description

grid#3
card# Fast
desc# Description here
card# Clean
desc# Description here
end#

divider#

img# image.png | Alt text
```

## File Structure

```
.
├── doctor.py              # The compiler (single file)
├── docs/
│   └── index.doctor       # Your docs (edit this)
├── .github/
│   └── workflows/
│       └── build.yml      # Auto-deploy to Pages
└── README.md
```

## Setup (One Time)

After forking:

1. Go to **Settings → Pages**
2. Set **Source** to "GitHub Actions"
3. Edit `docs/index.doctor` to write your docs
4. Every push to `main` rebuilds and deploys automatically

## Components

| Component | Syntax |
|-----------|--------|
| Title | `title# Page Title` |
| Nav | `nav# Label \| #href` |
| Sidebar | `sidebar# Label \| #href` |
| Hero | `hero# Title` + `desc# Subtitle` |
| Heading | `h1#`, `h2#`, `h3#` |
| Paragraph | `p# Text with **bold**` |
| Code | `code#lang` ... `end#` |
| Table | `table# Col1 \| Col2` ... `end#` |
| List | `list#` + `- item` ... `end#` |
| Alert | `alert#info` + `p# Text` |
| Card | `card# Title` + `desc# Text` |
| Grid | `grid#3` + cards ... `end#` |
| Divider | `divider#` |
| Image | `img# src.png \| alt` |

## License

MIT
